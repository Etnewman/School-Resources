public interface AmericanSocketAdaptee
{
	void provideElectricity(AmericanPinType americanPin);
}