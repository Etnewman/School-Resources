public interface BritishSocketTarget
{
	void provideElectricity(BritishPinType britishPin);
}