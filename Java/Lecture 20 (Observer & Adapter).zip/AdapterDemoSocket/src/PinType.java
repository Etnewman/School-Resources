public interface PinType
{

}

interface BritishPinType extends PinType 
{
	
}

interface AmericanPinType extends PinType
{
	
}